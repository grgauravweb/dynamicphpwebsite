<?php
session_start();
if(!isset($_SESSION['loggedin'])||$_SESSION['loggedin']!=true){
    header("location:index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - <?php echo $_SESSION['username'] ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <!-- jQuery and JS bundle w/ Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>
</head>

<body>
    <div class="container my-3">
        <h1>Welcome <?php echo $_SESSION['username'] ?> </h1>
        <br>
        <h2>Add Services</h2>
        <form name="card" action="card.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            Card title: <input type="text" name="service_name" class="form-control"><br>
        </div>
        <div class="form-group">
                    Card description: <textarea rows="3" name="query" class="form-control"
                        placeholder="card description" required></textarea><br>
        </div>
        <div class="form-group">
                    Upload card image: <input type="file" name="card_img" class="form-control"><br>
        </div>
        <div class="form-group">
                    <button type="submit" class="btn btn-success" name="add_card">Add Card</button>
        </div>
        </form>
        <h2>Add Company to your profile</h2><br>
        <form action="addcompany.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                Name: <input type="text" name="name" class="form-control"><br>
            </div>
            <div class="form-group">
                Address: <input type="text" name="address" class="form-control"><br>
            </div>
            <div class="form-group">
                Upload Image: <input type="file" name="profile_img" class="form-control"><br>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-success" name="add_company">Add company</button>
            </div>
        </form>
        <br>
        <h2>Add image to gallery</h2>
        <form action="admin.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            Name: <input type="text" name="galleryimg" class="form-control"><br>
</div>
            <div class="form-group">
            upload image: <input type="file" name="gallery" class="form-control"><br>
</div>
<div class="form-group">
            <button type="submit" class="btn btn-success" name="add_gallery">Add gallery</button>
</div>
        </form><br>
        <?php
include "connect.php";
if(isset($_POST["add_gallery"])){
    $name=$_POST['galleryimg'];
    $filename=$_FILES["gallery"]["name"];
    $tempname=$_FILES["gallery"]["tmp_name"];
    $folder="./gallery/".$filename;
    move_uploaded_file($tempname, $folder);
    $sql="INSERT INTO `gallery` (`name`, `img_path`) VALUES ('$name','$folder')";
  $sqlquery=mysqli_query($con,$sql);
  if($sqlquery){
      echo "Profile added successfully";
  }
  else{
      echo "Profile submission failed".mysqli_error();
  }
}
?>
        <div class="table-responsive-sm">
        <table class="table" border="2px">
            <tr>
                <th scope="col">id</th>
                <th scope="col">Name</th>
                <th scope="col">email</th>
                <th scope="col">phone</th>
                <th scope="col">query</th>
                <th scope="col">date</th>
                <th scope="col">Delete row</th>
            </tr>
            <?php
include "connect.php";
$sql="SELECT `id`, `name`, `email`, `phone`, `query`, `date` FROM query";
$result=mysqli_query($con,$sql);
if($result-> num_rows>0){
    while($row=$result-> fetch_assoc()){
        echo "<tr><td scope='row'>". $row["id"]."</td>
        <td scope='row'>". $row["name"]."</td>
        <td scope='row'>". $row["email"]."</td>
        <td scope='row'>". $row["phone"]."</td>
        <td scope='row'>". $row["query"]."</td>
        <td scope='row'>". $row["date"]."</td>
        <td scope='row'><a href='delete.php?id=$row[id]'>Delete</a></td>
        </tr>";
    }
    echo "</table>";
}
else {
    echo "0 result";
}
?>
        </table>
</div>
        <br>
        <a href="logout.php" class="btn btn-danger">logout</a>
    </div>
</body>

</html>