<?php
include "connect.php";
if(isset($_POST["add_company"])){
    $name=$_POST['name'];
    $address=$_POST['address'];
    $filename=$_FILES["profile_img"]["name"];
    $tempname=$_FILES["profile_img"]["tmp_name"];
    $folder="./profile_img/".$filename;
    move_uploaded_file($tempname, $folder);
    $sql="INSERT INTO `profile` (`name`, `address`, `img_path`) VALUES ('$name','$address','$folder')";
  $sqlquery=mysqli_query($con,$sql);
  if($sqlquery){
      echo "Profile added successfully";
  }
  else{
      echo "Profile submission failed".mysqli_error();
  }
}
header("location:admin.php");
?>