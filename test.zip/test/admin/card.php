<?php
include "connect.php";
if(isset($_POST["add_card"])){
    $service_name=$_POST['service_name'];
    $query=$_POST['query'];
    $filename=$_FILES["card_img"]["name"];
    $tempname=$_FILES["card_img"]["tmp_name"];
    $folder="./card_image/".$filename;
    move_uploaded_file($tempname, $folder);
    $sql="INSERT INTO `card_img` (`service_name`, `service_description`, `img_path`) VALUES ('$service_name','$query','$folder')";
  $sqlquery=mysqli_query($con,$sql);
  if($sqlquery){
      echo "Card added successfully";
  }
  else{
      echo "Card submission failed".mysqli_error();
  }
}
header("location:admin.php");
?>