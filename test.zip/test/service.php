<?php
error_reporting(0);
ini_set('display_errors', 0);
include "./admin/connect.php";
if (isset($_POST['submit'])){
  $name=$_POST['name'];
  $name=str_replace("<", "lt;", $name);
  $name=str_replace(">", "gt;", $name);
  $phone=$_POST['phone'];
  $email=$_POST['email'];
  $email=str_replace("<", "lt;", $email);
  $email=str_replace(">", "gt;", $email);
  $query=$_POST['query'];
  $query=str_replace("<", "lt;", $query);
  $query=str_replace(">", "gt;", $query);
  $name=stripcslashes($name);
  $email=stripcslashes($email);
  $phone=stripcslashes($phone);
  $query=stripcslashes($query);
  $name=mysqli_real_escape_string($con, $name);
  $phone=mysqli_real_escape_string($con, $phone);
  $email=mysqli_real_escape_string($con, $email);
  $query=mysqli_real_escape_string($con, $query);
  $sql="INSERT INTO `query` (`name`, `phone`, `email`, `query`) VALUES ('$name','$phone','$email','$query')";
  $sqlquery=mysqli_query($con,$sql);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home</title>
  <link rel="stylesheet" href="style.css">
  <!-- CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
    integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
  <!-- jQuery and JS bundle w/ Popper.js -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
    integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
    crossorigin="anonymous"></script>
</head>

<body>
  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
    <img src="./images/logo/logo.png" height="100px" width="100px" alt="" style="display:inline">
    <a href="index.php" style="text-decoration:none"><h2 style="color:red">Aman Roofing Works</h2></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="peb.php">PEB</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="service.php">Product and Services<span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="profile.php">Profile</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="gallery.php">Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About Us </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact Us</a>
        </li>
      </ul>
    </div>
  </nav><br><br>
  <br><br>
  <div class="container my-3">
    <h2 class="text-center">Products and Services</h2>
    <div class="row">
      <?php
  $card="SELECT `service_name`, `service_name`, `service_description`, `img_path` FROM card_img";
  $result=mysqli_query($con,$card);
  if($result-> num_rows>0){
  while($row=mysqli_fetch_assoc($result)){
      $src=$row['img_path'];
      $title=$row['service_name'];
      $description=$row['service_description'];
      $sub=substr($src,1);
        $path="./admin".$sub;
        ?>
      <div class="col-md-4">
        <?php
        echo "<div class='col-md-4 my-2'>
        <div class='card' style='width: 18rem;'>
          <img src='$path' class='card-img-top' alt='$title'>
          <div class='card-body'>
            <h5 class='card-title'>".$title."</h5>
            <p class='card-text'>".$description."</p>
          </div>
        </div>
      </div>
      </div>";
  }
}
  ?>
      </div>
    </div>

    <!-- Footer -->
    <footer class="page-footer font-small stylish-color-dark pt-4" style="background-color:#f5f5f5">

      <!-- Footer Links -->
      <div class="container text-center text-md-left">

        <!-- Grid row -->
        <div class="row">

          <!-- Grid column -->
          <div class="col-md-4 mx-auto">

            <!-- Content -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Aman Roofing Works</h5>
            <p>Aman Roofing Works, Vandana Enclave, Near, Rajat Vihar, Sector 62, Noida, Uttar Pradesh 201301 <br>
            Phone: <a href="tel:+919350195463">9350195463</a><br>
              Email: amanroofingworks@gmail.com
            </p>
            <hr>

            <!-- Call to action -->
            <ul class="list-unstyled list-inline text-center py-2">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.683262768876!2d77.34342701492277!3d28.609277382426985!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce5ea738b695b%3A0xcfdee63702dc6561!2sAman%20Roofing%20Works!5e0!3m2!1sen!2sin!4v1604140341032!5m2!1sen!2sin"
                width="200" height="200" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false"
                tabindex="0"></iframe>
            </ul>
            <!-- Call to action -->

            <hr>
          </div>
          <!-- Grid column -->

          <hr class="clearfix w-100 d-md-none">

          <!-- Grid column -->
          <div class="col-md-2 mx-auto">

            <!-- Links -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Follow us on</h5>

            <ul class="list-unstyled">
              <li>
                <a href="#!">facebook</a>
              </li>
            </ul>

          </div>


          <hr class="clearfix w-100 d-md-none">

          <!-- Grid column -->
          <div class="col-md-2 mx-auto">

            <!-- Links -->
            <h5 class="font-weight-bold text-uppercase mt-3 mb-4">Ask your query</h5>

            <ul class="list-unstyled">
              <li>
                <form action="index.php" method="post">
                  <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Full Name" required>
                  </div>
                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="name@example.com" required>
                  </div>
                  <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="tel" name="phone" class="form-control" placeholder="Phone" required>
                  </div>
                  <div class="form-group">
                    <label for="query">Ask your query</label>
                    <textarea rows="4" cols="50" name="query" class="form-control" placeholder="Ask your query"
                      required></textarea>
                  </div>
                  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
                  <?php
                if($sqlquery){
                  ?>
                  <script>alert("Your query is submitted successfully");</script>
                  <?php
                }
                ?>
                </form>
              </li>
            </ul>

          </div>
          <!-- Grid column -->

        </div>
        <!-- Grid row -->

      </div>

      <!-- Copyright -->
      <div class="footer-copyright text-center py-3">© 2020 Copyright:
        <a href="#"> amanroofingworks.com</a>
      </div>
      <!-- Copyright -->

    </footer>
    <!-- Footer -->
</body>

</html>